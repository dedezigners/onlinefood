<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<!--================Hero Banner Section start =================-->
<section class="hero-banner hero-banner-sm">
    <div class="hero-wrapper">
        <div class="hero-left">
            <h1 class="hero-title"><?php echo e($categoryName); ?></h1>
            <ul class="hero-info d-none d-lg-block">
               <?php $__currentLoopData = $RestaurantList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <img src="img/banner/fas-service-icon.png" alt="">
                    <h4><?php echo e($list->itemName); ?></h4>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <div class="hero-right">
            <div class="owl-carousel owl-theme w-100 hero-carousel">
                <div class="hero-carousel-item">
                    <img class="img-fluid" src="img/banner/hero-banner-sm.png" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<!--================Hero Banner Section end =================-->



<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/linksdevco/public_html/onRes/resources/views/front/menu.blade.php ENDPATH**/ ?>