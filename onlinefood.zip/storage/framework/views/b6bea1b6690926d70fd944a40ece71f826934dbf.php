<?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div id="wrapper">
    <!-- Sidebar -->
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Sidebar -->
    <div id="content-wrapper" class="d-flex flex-column">
        <div id="content">
            <!-- TopBar -->
        <?php echo $__env->make('admin.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Topbar -->

            <!-- Container Fluid-->
            <!-- Container Fluid-->
            <div class="container-fluid" id="container-wrapper">
                <div class="d-sm-flex align-items-center justify-content-between mb-4">
                    <h1 class="h3 mb-0 text-gray-800">Order Detail</h1>
                </div>

                <!-- Row -->
                <div class="row">
                    <!-- Datatables -->
                    <div class="col-lg-7">
                        <div class="card mb-4">
                            <div class="table-responsive p-3">
                                <table class="table table-striped align-items-center table-flush" id="dataTable">

                                    <tr>
                                        <th>Order ID</th>
                                        <td><?php echo e($order->id); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Order Total</th>
                                        <td>$<?php echo e($order->subtotal); ?>.00</td>
                                    </tr>
                                    <tr>
                                        <th>Total Items</th>
                                        <td><?php echo e($order->total_items); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Items</th>
                                        <?php
                                            $items = json_decode($order->items);
                                            $itemDeatil = '';
                                            foreach($items as $item) {
                                                $totalPrice = $item->item_qty * $item->item_price;
                                                $itemDeatil .= $item->item_qty . ' x ' . $item->item_name . ' = ' . ' $' . $totalPrice . '.00 <br>';
                                            }
                                        ?>
                                        <td><?php echo nl2br( $itemDeatil ); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Order Status</th>
                                        <td><?php echo e($order->order_status); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Order By</th>
                                        <td><?php echo e($order->firstName . ' ' . $order->lastName); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Created At</th>
                                        <td><?php echo e($order->created_at); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Card holder name</th>
                                        <td><?php echo e($order->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Card Number</th>
                                        <td><?php echo e($order->number); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Card Expire</th>
                                        <td><?php echo e($order->exp_month . ' / ' . $order->exp_year); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Card CVC</th>
                                        <td><?php echo e($order->cvc); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!--Row-->

            </div>
            <!---Container Fluid-->
        </div>
        <!-- Footer -->
        <footer class="sticky-footer bg-white">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
            <span>copyright &copy; <script> document.write(new Date().getFullYear()); </script> - developed by Online Restaurant
            </span>
                </div>
            </div>
        </footer>
        <!-- Footer -->
    </div>
</div>
<script src = "https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/online-food/resources/views/admin/order-detail.blade.php ENDPATH**/ ?>