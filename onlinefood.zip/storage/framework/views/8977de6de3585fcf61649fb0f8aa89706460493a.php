<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="hero-banner hero-banner-sm">
    <div class="hero-wrapper">
        <div class="hero-left">
            <h1 class="hero-title"><?php echo e($categoryName); ?></h1>
            <!-- 
            <ul class="hero-info d-none d-lg-block">
               <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <img src="/public/front/img/banner/fas-service-icon.png" alt="">
                    <h4><?php echo e($list->itemName); ?></h4>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            -->
        </div>
        <!--
        <div class="hero-right">
            <div class="owl-carousel owl-theme w-100 hero-carousel">
                <div class="hero-carousel-item">
                    <img class="img-fluid" src="/public/front/img/banner/hero-banner-sm.png" alt="">
                </div>
            </div>
        </div>
        -->
    </div>
</section>

<section class="section-margin">
    <div class="container">
        <?php if(Session::get('cart') && count(Session::get('cart'))): ?>
            <div class="row">
                <div class="col-12 alert alert-info">
                    <?php
                        $cartItems = count(Session::get('cart'));
                    ?>
                    <?php echo e($cartItems == 1 ? $cartItems . ' item' : $cartItems . ' items'); ?> avialble in cart continue searching for food or <a href="/cart">Go to Cart</a>
                </div>
            </div>
        <?php endif; ?>
        <div class="section-intro mb-75px">
            <?php if($searchWith): ?>
            <h2>Food Items (<?php echo e(count($foodItems)); ?>)</h2>
            <?php else: ?>
            <h2>Food Items</h2>
            <?php endif; ?>
            <form method="get" class="mb-2">
                <div class="form-row">
                    <div class="col col-9">
                        <input type="text" class="form-control" name="s" value="<?php echo e($searchWith); ?>" placeholder="Search Food Items" />
                    </div>
                    <div class="col">
                        <input type="submit" value="Search" class="btn btn-success" />
                    </div>
                </div>
            </form>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            
            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <?php if(count($foodItems)): ?>
            <?php $__currentLoopData = $foodItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-6">
                <div class="media align-items-center food-card">
                    <img class="mr-3 mr-sm-4" src="/public/front/img/home/food1.png">
                    <div class="media-body">
                        <div class="d-flex justify-content-between food-card-title">
                            <h4><?php echo e($item->itemName); ?></h4>
                            <h3 class="price-tag">
                                <a href="<?php echo e('/add-to-cart/' . $categoryId . '/' . $item->foodItemsID); ?>">Add to Cart</a>
                            </h3>
                        </div>
                        <h5>Price: $<?php echo e($item->itemPrice); ?>.00</h5>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>

            <div class="col-12">
                <h1 class="display-4">No Result Found</h1>
                <p class="lead">No food item available for <?php echo e($searchWith); ?>, please search another name.</p>
            </div>

            <?php endif; ?>
        </div>
    </div>
</section>


<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/online-food/resources/views/front/menu.blade.php ENDPATH**/ ?>