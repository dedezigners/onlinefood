<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--================Food menu section start =================-->
<section class="section-margin">
    <div class="container">
        <div class="section-intro mb-75px">
            <h2>Restaurant List</h2
             <form class="form-inline" id="formId" action="<?php echo e(url('/')); ?>/restaurant">
               <input type="text" class="form-control" name="search" placeholder="Search By Restaurant, Category or Food Item" />
               <input type="button" value="Search" class="btn btn-success" onClick='submitDetailsForm()'  />
           </form>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>


            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <?php $__currentLoopData = $RestaurantList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MainList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-6">
                <div class="media align-items-center food-card">
                    <img class="mr-3 mr-sm-4" src="<?php echo e(url('/')); ?>/public/front/img/home/food1.png" alt="">
                    <div class="media-body">
                        <div class="d-flex justify-content-between food-card-title">
                            <h4><?php if($MainList->restaurantName): ?><?php echo e($MainList->restaurantName); ?> <?php else: ?> Unknown <?php endif; ?></h4>
                            <h3 class="price-tag"><a href="<?php echo e(url('/').'/book/'.$MainList->restaurantID.'/seats'); ?>">Book Your Seat</a></h3>
                        </div>
                       <?php
                         $getCategory = \App\Category::where('restaurantID',$MainList->restaurantID)->get();
                        ?>
                        <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><a href="<?php echo e(url('/').'/view/'.$list->categoryID.'/foodItems'); ?>"><?php echo e($list->categoryName); ?></a></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<script language="javascript" type="text/javascript">
    function submitDetailsForm() {
       $("#formId").submit();
    }
</script>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/linksdevco/public_html/onRes/resources/views/front/restaurant.blade.php ENDPATH**/ ?>