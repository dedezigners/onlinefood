<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="section-margin">
    <div class="container">

        <?php if(Session::get('cart') && count(Session::get('cart'))): ?>
            <div class="row">
                <div class="col-12 alert alert-info">
                    <?php
                        $cartItems = count(Session::get('cart'));
                    ?>
                    <?php echo e($cartItems == 1 ? $cartItems . ' item' : $cartItems . ' items'); ?> avialble in cart continue searching for food or <a href="/cart">Go to Cart</a>
                </div>
            </div>
        <?php endif; ?>

        <div class="section-intro mb-75px">
            <?php if($searchWith): ?>
            <h2>Restaurant List (<?php echo e(count($RestaurantList)); ?>)</h2>
            <?php else: ?>
            <h2>Restaurant List</h2>
            <?php endif; ?>
            <form method="get" class="mb-5">
                <div class="form-row">
                    <div class="col col-9">
                        <input type="text" class="form-control" name="s" value="<?php echo e($searchWith); ?>" placeholder="Search By Restaurant" />
                    </div>
                    <div class="col">
                        <input type="submit" value="Search" class="btn btn-success" />
                    </div>
                </div>
            </form>

            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>


            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <div class="row">
            <?php if(count($RestaurantList)): ?>
            <?php $__currentLoopData = $RestaurantList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $MainList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-lg-6">
                <div class="media align-items-center food-card">
                    <img class="mr-3 mr-sm-4" src="<?php echo e(url('/')); ?>/public/front/img/home/food1.png" alt="">
                    <div class="media-body">
                        <div class="d-flex justify-content-between food-card-title">
                            <h4><?php if($MainList->restaurantName): ?><?php echo e($MainList->restaurantName); ?> <?php else: ?> Unknown <?php endif; ?></h4>
                            <h3 class="price-tag"><a href="<?php echo e(url('/').'/book/'.$MainList->restaurantID.'/seats'); ?>">Book Your Seat</a></h3>
                        </div>
                       <?php
                         $getCategory = \App\Category::where('restaurantID',$MainList->restaurantID)->get();
                        ?>
                        <?php $__currentLoopData = $getCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><a href="<?php echo e(url('/').'/view/'.$list->categoryID.'/foodItems'); ?>"><?php echo e($list->categoryName); ?></a></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-12">
                    <h1 class="display-4">No Result Found</h1>
                    <p class="lead">No restaurent available for <?php echo e($searchWith); ?>, please search another name.</p>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>

<script language="javascript" type="text/javascript">
    function submitDetailsForm() {
       $("#formId").submit();
    }
</script>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/online-food/resources/views/front/restaurant.blade.php ENDPATH**/ ?>