<!-- Scroll to top -->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<script src="<?php echo e(url('/')); ?>/public/admin/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/admin/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/admin/vendor/jquery-easing/jquery.easing.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/admin/js/ruang-admin.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/admin/vendor/chart.js/Chart.min.js"></script>
<script src="<?php echo e(url('/')); ?>/public/admin/js/demo/chart-area-demo.js"></script>
</body>

</html><?php /**PATH /var/www/online-food/resources/views/admin/footer.blade.php ENDPATH**/ ?>