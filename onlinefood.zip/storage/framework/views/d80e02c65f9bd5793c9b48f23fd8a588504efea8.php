<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="hero-banner hero-banner-sm">
    <div class="hero-wrapper">
        <div class="hero-left">
            <h1 class="hero-title">Shopping Cart</h1>
        </div>
    </div>
</section>

<section class="bg-lightGray section-padding">
    <div class="container">
        <div class="row align-items-top cart">
            
            <form class="col-md-8 col-sm-12" method="post" action="/update-cart">
                <?php echo csrf_field(); ?>
                <a href="/clear-cart"><i class="ti-close"></i> Remove All</a>
                <table class="table">
                    <tr>
                        <th>Sr #</th>
                        <th>Product</th>
                        <th>Item Price</th>
                        <th>Qty</th>
                        <th>Total</th>
                        <th></th>
                    </tr>
                    
                    <?php $i = 0; $subTotal = 0; $restaurantId = 0; $items = []; ?>
                    <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php 
                        $i++;
                        $restaurantId = $item['restaurant_id'];
                        $itemPrice = $item['item_price'];
                        $itemName = $item['item_name'];
                        $itemQty = $item['item_qty'];
                        $itemTotal = $itemPrice * $itemQty;
                        $itemDetail = $itemQty . ' x ' . $itemName . ' = $' . $itemTotal . '.00';
                        array_push($items, $itemDetail);
                        $subTotal += $itemTotal;
                    ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($itemName); ?></td>
                        <td>$<?php echo e($itemPrice); ?>.00</td>
                        <td><input class="form-control" min="1" type="number" name="qty[]" value="<?php echo e($itemQty); ?>" /></td>
                        <td>$<?php echo e($itemTotal); ?>.00</td>
                        <td><a href="/clear-item/<?php echo e($item['item_id']); ?>"><i class="ti-close"></i></a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>

                <input type="submit" class="btn btn-sm float-right" value="Update Cart">
            </form>

            <form class="col-md-4 col-sm-12" method="POST" action="/checkout">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="type" value="order">
                <input type="hidden" name="restaurantID" value="<?php echo e($restaurantId); ?>">
                <input type="hidden" name="total_amount" value="<?php echo e($subTotal); ?>">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="hidden" name="items[]" value="<?php echo e($item); ?>">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="subtotal">
                    <h4>Order Summary</h4>
                    <ul>
                        <li>
                            <span class="left-summary">Sub-Total:</span>
                            <span class="right-summary">$<?php echo e($subTotal); ?>.00</span>
                        </li>
                        <li>
                            <span class="left-summary">Shipping:</span>
                            <span class="right-summary">$0.00</span>
                        </li>
                        <li>
                            <span class="left-summary">Tax:</span>
                            <span class="right-summary">$0.00</span>
                        </li>
                        <li>
                            <span class="left-summary">Total:</span>
                            <span class="right-summary">$<?php echo e($subTotal); ?>.00</span>
                        </li>
                    </ul>
                    
                    <button type="submit" class="button btn-block">Checkout</button>
                </div>
            </form>
        </div>
    </div>
</section>

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/online-food/resources/views/front/cart.blade.php ENDPATH**/ ?>