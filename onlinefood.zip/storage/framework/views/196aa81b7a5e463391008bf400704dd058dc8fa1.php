<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ================ contact section start ================= -->
<section class="section-margin">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="contact-title">Register</h2>
            </div>
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>


            <?php if($message = Session::get('error')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="col-lg-12">
                <form method="post" action="<?php echo e(url('/')); ?>/register">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>First Name</label>
                        <input name="firstName" value="<?php echo e(old('firstName')); ?>" type="text" class="form-control" id="exampleInputFirstName" placeholder="Enter First Name">
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input name="lastName" value="<?php echo e(old('lastName')); ?>" type="text" class="form-control" id="exampleInputLastName" placeholder="Enter Last Name">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input name="email" value="<?php echo e(old('email')); ?>"  type="email" class="form-control" id="exampleInputEmail" aria-describedby="emailHelp"
                               placeholder="Enter Email Address">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input name="password" value="<?php echo e(old('password')); ?>" type="password" class="form-control" id="exampleInputPassword" placeholder="Password">
                    </div>
                    <div class="form-group">
                        <label>Repeat Password</label>
                        <input name="password_confirmation" value="<?php echo e(old('password_confirmation')); ?>" type="password" class="form-control" id="exampleInputPasswordRepeat"
                               placeholder="Repeat Password">
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
                    </div>
                    <hr>
                    <a href="<?php echo e(url('/')); ?>/login">Login</a>
                </form>


            </div>
        </div>
    </div>
</section>
<!-- ================ contact section end ================= -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/online-food/resources/views/front/register.blade.php ENDPATH**/ ?>