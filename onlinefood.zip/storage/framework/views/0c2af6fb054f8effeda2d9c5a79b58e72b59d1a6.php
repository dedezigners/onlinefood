<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="bg-lightGray section-padding">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6 col-xl-5 mb-4 mb-md-0">
                <div class="section-intro">
                    <h4 class="intro-title">Reservation</h4>
                    <h2 class="mb-3"><?php echo e($RestaurantList->restaurantName); ?></h2>
                </div>
                <p><?php echo e($RestaurantList->description); ?></p>
            </div>
            <div class="col-md-6 offset-xl-2 col-xl-5">
                <div class="search-wrapper">
                    <h3>Book A Table</h3>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>


                    <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-danger alert-block">
                            <button type="button" class="close" data-dismiss="alert">×</button>
                            <strong><?php echo e($message); ?></strong>
                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php if($errors->any()): ?>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form class="search-form" method="post" action="<?php echo e(url('/')); ?>/saveReservation">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" class="form-control" name="name" placeholder="Your Name" value="<?php echo e(old('name')); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-user"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="email" class="form-control" name="email" placeholder="Email Address" value="<?php echo e(old('email')); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-email"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" class="form-control" name="phoneNumber" placeholder="Phone Number" value="<?php echo e(old('phoneNumber')); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-headphone-alt"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="datetime-local" class="form-control" name="expectedTime" placeholder="Select Date" value="<?php echo e(old('expectedTime')); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-notepad"></i></span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <input type="number" name="size" class="form-control" placeholder="Select People" value="<?php echo e(old('size')); ?>">
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="ti-layout-column3"></i></span>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" name="restaurantID" value="<?php echo e($restaurantID); ?>">
                        <div class="form-group form-group-position">
                            <button class="button border-0" type="submit">Make Reservation</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================Reservation section end =================-->


<!--================Blog section start =================-->

























































<!--================Blog section end =================-->

<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/linksdevco/public_html/onRes/resources/views/front/bookSeats.blade.php ENDPATH**/ ?>